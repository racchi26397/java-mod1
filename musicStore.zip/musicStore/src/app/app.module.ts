import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from "@angular/common/http";
import {FormsModule} from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AddAlbumComponent } from './MusicStore/add-album.component';
import { ListAlbumComponent } from './MusicStore/list-album.component';
import { HomeComponent } from './MusicStore/home.component';
import { SearchAlbumComponent } from './MusicStore/search-album.component';
import { MusicService } from './music.service';
import { MusicupdateComponent } from './MusicStore/musicupdate.component';

@NgModule({
  declarations: [
    AppComponent,
    AddAlbumComponent,
    ListAlbumComponent,
    HomeComponent,
    SearchAlbumComponent,
    MusicupdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [MusicService],
  bootstrap: [AppComponent]
})
export class AppModule { }
