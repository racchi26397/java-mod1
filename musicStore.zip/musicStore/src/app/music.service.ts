import { Injectable } from '@angular/core';
import { Music } from './MusicStore/music';
import {HttpClient} from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MusicService {
musics:Music[];

  constructor(private http:HttpClient) {
    this.populateMusic().subscribe(data=>this.musics=data,error=>console.log(error));
   }

   populateMusic():Observable<Music[]>{
    return this.http.get<Music[]>(".//../assets/music.json");
  }

  getMusics():Music[]{
    return this.musics;
  }

  addAlbum(music:Music){
    return this.musics.push(music);
    return this.getMusics();
  }
  
   deleteMusic(id){
     if(confirm("Are you sure?")){
        this.musics=this.musics.filter(msc=>msc.id!=id);
     }
    }

     onsave(musics:Music){

      let index=this.musics.findIndex(mus=>mus.id===musics.id)
      this.musics[index].id=musics.id;
      this.musics[index].artist=musics.artist;
      this.musics[index].title=musics.title;
      this.musics[index].price=musics.price;
     alert("Details Saved");
    }
  }
 
