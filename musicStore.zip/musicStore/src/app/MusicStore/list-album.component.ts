import { Component, OnInit } from '@angular/core';
import { MusicService } from '../music.service';
import { Music } from './music';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-album',
  templateUrl: './list-album.component.html',
  styleUrls: ['./list-album.component.css']
})
export class ListAlbumComponent implements OnInit {
  musics:Music[];
  constructor(private musicService:MusicService,private route:Router) { }

  ngOnInit() {
    this.musics=this.musicService.getMusics();
  }
  deleteMusic(id){
    this.musicService.deleteMusic(id);
    this.musics=this.musicService.getMusics();
  }
  navigateTo(id){
    this.route.navigate(["/update",id]);
  }
}
