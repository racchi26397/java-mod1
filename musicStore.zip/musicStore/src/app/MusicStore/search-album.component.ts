import { Component, OnInit } from '@angular/core';
import { Music } from './music';
import { MusicService } from '../music.service';

@Component({
  selector: 'app-search-album',
  templateUrl: './search-album.component.html',
  styleUrls: ['./search-album.component.css']
})
export class SearchAlbumComponent implements OnInit {
  musics:Music[];

  constructor(private musicService:MusicService) { }

  ngOnInit() {
  }
  search(data){
    console.log(data.searchTerm);
    this.musics=this.musicService.getMusics().filter(msc =>msc.title === data.searchTerm );
    if(this.musics.length==0){
      this.musics=this.musicService.getMusics().filter(msc =>msc.artist === data.searchTerm );
  }
}
}
