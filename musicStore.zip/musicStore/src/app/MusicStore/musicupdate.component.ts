import { Component, OnInit } from '@angular/core';
import { Music } from './music';
import { MusicService } from '../music.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-musicupdate',
  templateUrl: './musicupdate.component.html',
  styleUrls: ['./musicupdate.component.css']
})
export class MusicupdateComponent implements OnInit {
  musics:Music;
  constructor(private musicService:MusicService, private activatedRoute: ActivatedRoute, private router: Router) { }
 

  navigateBack() {
    this.router.navigate(['/musics']);
  }

  ngOnInit() {
    let musicId = this.activatedRoute.snapshot.params["id"];
    this.musics=this.musicService.getMusics().find(e=>e.id==musicId);
  }
  onsave(music){
    this.musicService.onsave(music);
    this.router.navigate(['/musics']);
  } 

}
