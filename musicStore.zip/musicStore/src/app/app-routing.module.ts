import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListAlbumComponent } from './MusicStore/list-album.component';
import { AddAlbumComponent } from './MusicStore/add-album.component';
import { HomeComponent } from './MusicStore/home.component';
import { SearchAlbumComponent } from './MusicStore/search-album.component';
import { MusicupdateComponent } from './MusicStore/musicupdate.component';


const routes: Routes = [{path:"list",component:ListAlbumComponent},
{path:"add",component:AddAlbumComponent},
{path:'',component:HomeComponent},
{path:"musics",component:ListAlbumComponent},
{path:"update/:id",component:MusicupdateComponent},
{path:"search",component:SearchAlbumComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
